# My Node.js Project

This project is a simple Node.js application that sets up an Express server with a custom API for user authentication using Supabase.

## Project Structure

```
my-nodejs-project
├── src
│   ├── server.js        # Main server file with API endpoints
├── package.json         # npm configuration file
└── README.md            # Project documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd my-nodejs-project
   ```

2. Install the dependencies:
   ```
   npm install
   ```

## Usage

To start the server, run the following command:
```
npm start
```

The server will be running on `http://localhost:3000`.

## API Endpoints

- **POST /login**
  - Description: Authenticates a user with a username and password.
  - Request Body:
    ```json
    {
      "username": "your_username",
      "password": "your_password"
    }
    ```
  - Response:
    - Success: Returns user data if found.
    - Error: Returns an error message if the user is not found or if there is an issue.

- **GET /websocket**
  - Description: Endpoint for WebSocket connections.
  - Response: Returns a message indicating the WebSocket endpoint.

## License

This project is licensed under the MIT License.