const express = require('express');
const router = express.Router();
const fetch = require('node-fetch'); // Certifique-se de que a biblioteca está instalada

const SUPABASE_URL = "https://cxsjxglqsmdpyuqsubxk.supabase.co/rest/v1/users";
const API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN4c2p4Z2xxc21kcHl1cXN1YnhrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA1MTM0MjUsImV4cCI6MjA1NjA4OTQyNX0.51YOv_a8-E_hMeC1TjLU1fnmBl5nUqKP6YatilsU1NM";

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: "Please fill in both fields." });
  }

  const url = `${SUPABASE_URL}?username=eq.${username}&password=eq.${password}`;
  const options = {
    method: "GET",
    headers: {
      apikey: API_KEY,
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    }
  };

  try {
    const response = await fetch(url, options);
    const data = await response.json();
    if (data.length > 0) {
      res.json({ message: "User found", user: data[0] });
    } else {
      res.status(404).json({ message: "User not found. Please try again." });
    }
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ message: "Error fetching user. Please try again later." });
  }
});

router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: "Please fill in both fields." });
  }

  const url = SUPABASE_URL;
  const options = {
    method: "POST",
    headers: {
      apikey: API_KEY,
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ username, password })
  };

  try {
    const response = await fetch(url, options);
    const data = await response.json();
    console.log("Supabase response:", data); // Adicionando log para ver a resposta do Supabase
    if (response.ok) {
      res.status(201).json({ message: "User created successfully", user: data });
    } else {
      res.status(response.status).json({ message: "Error creating user", error: data });
    }
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ message: "Error creating user. Please try again later." });
  }
});

router.get('/websocket', (req, res) => {
  // Implement WebSocket connection logic here
  res.json({ message: "WebSocket endpoint" });
});

module.exports = router;